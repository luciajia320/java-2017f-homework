package default1;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * Unit test for simple App.
 */
public class AppTest 
    extends TestCase
{
    /**
     * Create the test case
     *
     * @param testName name of the test case
     */
    public AppTest( String testName )
    {
        super( testName );
    }

    /**
     * @return the suite of tests being tested
     */
    public static Test suite()
    {
        return new TestSuite( AppTest.class );
    }

    /**
     * Rigourous Test :-)
     */
    public void testApp()
    {
    	save a=null;
    	save b=null;
    	ObjectOutputStream oos=null;  
	      try{  
	         oos=new ObjectOutputStream(new FileOutputStream("test.txt"));  
	         a=new save();
	         for(int i=0;i<8;i++)
	 		 {
	 			for(int j=0;j<16;j++)
	 			{
	 					a.savedata[i][j]=i;
	 				
	 			}
	 		 }
	  
	         oos.writeObject(a);
	         b=new save();
	         for(int i=0;i<8;i++)
		 	{
		 			for(int j=0;j<16;j++)
		 			{
		 					b.savedata[i][j]=9-i;
		 				
		 			}
		 	}
	         oos.writeObject(b);  
	        }catch(Exception e){  
	             e.printStackTrace();  
	        }finally{  
	             if(oos!=null)  
	             try{  
	                oos.close();  
	              }catch(Exception e){  
	                   e.printStackTrace();  
	             }  
	          }  
	      ObjectInputStream ois=null; 
	      try {
			ois=new ObjectInputStream(  
			     new FileInputStream("test.txt"));
			
              save p = (save)ois.readObject();
              for(int i=0;i<8;i++)
 	 		 {
 	 			for(int j=0;j<16;j++)
 	 			{
 	 				assertEquals(a.savedata[i][j],p.savedata[i][j]);
 	 					
 	 				
 	 			}
 	 		 }
              
              p = (save)ois.readObject();
              for(int i=0;i<8;i++)
  	 		 {
  	 			for(int j=0;j<16;j++)
  	 			{
  	 				assertEquals(b.savedata[i][j],p.savedata[i][j]);
  	 					
  	 				
  	 			}
  	 		 }
          
		} catch (EOFException e) {//ͨ���쳣���ж��ļ���ȡ����β
          }
	      catch (Exception e) {//
	          e.printStackTrace();
	      
	      
}
    }
}
