package default1;


import java.awt.Image;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.URL;
import java.util.Random;
import javax.swing.ImageIcon;

public class Player extends Thing2D implements Runnable {
    private Field field;
    public SENIORITY seniority;
    private final int OFFSET = 0;
    private final int SPACE = 20;
    public Player(int x, int y, Field field,SENIORITY seniority) {
        super(x, y);
        this.seniority=seniority;
        this.field = field;
        URL loc;
        //loc = this.getClass().getClassLoader().getResource("player.png");
        if(seniority==SENIORITY.一)
        {
        	loc = this.getClass().getClassLoader().getResource("Huluwa1.png");
        }
        else if(seniority==SENIORITY.二)
        {
        	loc = this.getClass().getClassLoader().getResource("Huluwa2.png");
        }
        else if(seniority==SENIORITY.三)
        {
        	loc = this.getClass().getClassLoader().getResource("Huluwa3.png");
        }
        else if(seniority==SENIORITY.四)
        {
        	loc = this.getClass().getClassLoader().getResource("Huluwa4.png");
        }
        else if(seniority==SENIORITY.五)
        {
        	loc = this.getClass().getClassLoader().getResource("Huluwa5.png");
        }
        else if(seniority==SENIORITY.六)
        {
        	loc = this.getClass().getClassLoader().getResource("Huluwa6.png");
        }
        else if(seniority==SENIORITY.七)
        {
        	loc = this.getClass().getClassLoader().getResource("Huluwa7.png");
        }
        else if(seniority==SENIORITY.爷爷)
        {
        	loc = this.getClass().getClassLoader().getResource("Yeye.png");
        }
        else if(seniority==SENIORITY.蝎子精)
        {
        	loc = this.getClass().getClassLoader().getResource("Xiezijing.png");
        }
        else if(seniority==SENIORITY.蛇精)
        {
        	loc = this.getClass().getClassLoader().getResource("Shejing.png");
        }
        else 
        {
        	loc = this.getClass().getClassLoader().getResource("Xiaolouluo.png");
        }
        ImageIcon iia = new ImageIcon(loc);
        Image image = iia.getImage();
        this.setImage(image);
    }

    public void move(int x, int y) {
        int nx = this.x() + x;
        int ny = this.y() + y;
        this.setX(nx);
        this.setY(ny);
    }
    public void setxy(int x,int y)
    {
    	this.setX(x);
        this.setY(y);
    }
    
    public void run() {
    	
    		
    	
    	boolean exit = false;
        while (!Thread.interrupted() && exit==false) {
        	int k=0;
        	if(this instanceof Huluwa || this instanceof Yeye )
        	{
        		k=1;
        	}
        	else
        		k=-1;
        	if(k==1 && this.x()>=160)
        	{
        		exit=true;
        	}
        	else if(k==-1 && this.x()<=50)
        	{
        		exit=true;
        	}
            Random rand = new Random();
            int i=rand.nextInt(2);
            synchronized(Square.square)
            {
            if(Square.check()==false)
            {
            	save a=new save();
     	         a=a.mysave();
            	exit=true;
            	if(this instanceof Yeye)
            	{
            		try {
						writefile.writein();
					} catch (FileNotFoundException e) {
						// TODO �Զ����ɵ� catch ��
						e.printStackTrace();
					} catch (IOException e) {
						// TODO �Զ����ɵ� catch ��
						e.printStackTrace();
					}
            	}
            	
            }
            if(i==1)
            {
            if(k==1)
            {
            	if(Square.get(this.y()/SPACE, this.x()/SPACE+i)==2)
            	{
            		i=0;
            	}
            	else
            	{
            		Square.set(this.y()/SPACE, this.x()/SPACE, 0);
            		Square.set(this.y()/SPACE, this.x()/SPACE+i, 1); 
            	}
            
            }
            else if(k==-1)
            {
            	if(Square.get(this.y()/SPACE, this.x()/SPACE-i)==1)
            	{
            		
            		exit=true;
            		i=0;
            		Square.set(this.y()/SPACE, this.x()/SPACE, 0);
            	}
            	else
            	{
            		Square.set(this.y()/SPACE, this.x()/SPACE, 0);
            		Square.set(this.y()/SPACE, this.x()/SPACE-i, 2);
            	}
            
            }
            System.out.println();
            //Square.show();
            }
            
            }
            this.move(i*k*SPACE, 0);
            if(exit==true && k==-1)
            {
            	this.setImage(null);
            }
            if(i==1)
            {
            	save a=new save();
    	         writefile.all.add(a);
            }
            
            try {

                Thread.sleep(rand.nextInt(100) + 1000);
                
                this.field.repaint();

            } catch (Exception e) {

            }
            
        }
    }
}