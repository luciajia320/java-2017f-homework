package default1;
public interface Comparable {

    public boolean biggerThan(Comparable another);
}
