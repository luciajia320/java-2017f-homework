package default1;
public interface Creature   {

    public void report();
    public void setPosition(Position position);

    public Position getPosition();
    public void setxy(int x,int y);


}
