package default1;
public interface Sorter {

    public void sort(Huluwa[] a);
}
