package default1;
public class Xiaolouluo extends Player implements Creature, Comparable{

    private SENIORITY seniority;
    private Position position;


    public SENIORITY getSeniority() {
        return seniority;
    }


    public Position getPosition() {
        return position;
    }
    @Override
    public void setxy(int x,int y) {
        super.setxy(x, y);
    }
    public void setPosition(Position position) {
        this.position = position;
        position.setHolder(this);
    }

    Xiaolouluo(SENIORITY seiority,int x, int y, Field field) {
    	super(x,y,field,seiority);
    	super.seniority=seiority;
        this.seniority = seiority;
    }

    public void report() {
    	//System.out.print(this.toString());
    	System.out.print("�");
    }

    @Override
    public String toString(){
        return this.seniority.toString() + "@" + this.position.getX()+ " "+this.position.getY() + ";";
    }

    public boolean biggerThan(Comparable brother){

        if (brother instanceof  Huluwa)
            return this.getSeniority().ordinal()> ((Huluwa) brother).getSeniority().ordinal();
        else
            return false;
    }

}