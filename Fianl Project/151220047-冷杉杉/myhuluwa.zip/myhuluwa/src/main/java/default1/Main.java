package default1;

import java.io.FileNotFoundException;
import java.net.MalformedURLException;

public class Main {
	public static void main(String[] args) throws MalformedURLException, FileNotFoundException {
        Ground ground = new Ground();
        ground.setVisible(true);
    }
	
}
