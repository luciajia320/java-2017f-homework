package default1;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.*;

public class save implements Serializable {
	public  int[][] savedata=new int [8][16];
	public save()
	{
		for(int i=0;i<8;i++)
		{
			for(int j=0;j<16;j++)
			{
					savedata[i][j]=Square.get(i, j);
				
			}
		}
	}
	public String toString() {
	
		StringBuilder b=new StringBuilder();
		for(int i=0;i<8;i++)
		{
			for(int j=0;j<16;j++)
			{
					b.append(savedata[i][j]);
				
			}
			b.append("\n");
		}
		return b.toString();
	}
	public save mysave()
	{
		
		save a=new save();
	      
	         
	         writefile.all.add(a);
	      return a;
	}
	public save[] myload(File file)
	{
		Vector<save> temp=new Vector<save>();
		ObjectInputStream ois=null; 
		save[] p=null;
	      try {
			ois=new ObjectInputStream(  
			     new FileInputStream(file.getName()));
			while (true) {
                temp.add((save)ois.readObject());
                
            }
		} catch (EOFException e) {//ͨ���쳣���ж��ļ���ȡ����β
            //System.out.println("�ļ���ȡ��ϣ�");
			}
	      catch (Exception e) {//
	          e.printStackTrace();
      }
	      p=new save[temp.size()];
	      temp.toArray(p);
	      return p;
	}
}
