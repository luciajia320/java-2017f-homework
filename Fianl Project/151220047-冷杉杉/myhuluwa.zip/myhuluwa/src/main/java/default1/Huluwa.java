package default1;
public class Huluwa extends Player implements Creature, Comparable{

    private COLOR color;
    private SENIORITY seniority;
    private Position position;

    public COLOR getColor() {
        return color;
    }

    public SENIORITY getSeniority() {
        return seniority;
    }

    @Override
    public void setxy(int x,int y) {
        super.setxy(x, y);
    }
    public Position getPosition() {
        return position;
    }

    public void setPosition(Position position) {
        this.position = position;
        position.setHolder(this);
    }

    Huluwa(COLOR color, SENIORITY seiority,int x, int y, Field field) {
    	super(x,y,field,seiority);
        this.color = color;
        this.seniority = seiority;
    }

    
    public void report() {
        //System.out.print(this.toString());
    	//System.out.print(seniority+"娃             ");
    	System.out.print(this.color.toString());
    }

    @Override
    public String toString(){
        return this.seniority.toString() + "(" + this.color.toString() + ")@" + this.position.getX() + " "+this.position.getY() + ";";
    }

    
    public boolean biggerThan(Comparable brother){

        if (brother instanceof  Huluwa)
            return this.getSeniority().ordinal()> ((Huluwa) brother).getSeniority().ordinal();
        else
            return false;
    }

}

enum COLOR {
    赤, 橙, 黄, 绿, 青, 蓝, 紫
}

enum SENIORITY {
    一, 二, 三, 四, 五, 六, 七 ,爷爷, 蝎子精, 小喽啰,蛇精,
}