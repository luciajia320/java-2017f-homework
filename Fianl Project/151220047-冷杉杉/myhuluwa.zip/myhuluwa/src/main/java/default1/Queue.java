package default1;
import java.util.Random;

public class Queue {

	final int N=11;
    private Position[][] positions;

    public Position[][] getPositions() {
        return positions;
    }


    public Creature[] getCreatures() {
        return creatures;
    }
    


    private Creature[] creatures;

    public Queue(Creature[] creatures) {


        this.positions =new Position[N][N];

        this.creatures = creatures;

      
        for (int i = 0; i < creatures.length; i++) {
        	
        	if(creatures[i] instanceof  Huluwa && i<N)
        	{
        		creatures[i].setxy(i,0);
        		this.positions[i][0] =new Position(i,0);
        		this.creatures[i].setPosition(this.positions[i][0]);
        	}
        	
        	
        	
        }
    }
    public void print()
    {
    	for(int i=0;i<N;i++)
    	{
    		for(int j=0;j<N;j++)
    		{
    			if(this.positions[i][j]==null )
     			{
     				System.out.print("  ");
     			}
     			else
     				positions[i][j].show();
    		}
    		System.out.println();
    	}
    }
    public void clear()
    {
    	for(int i=0;i<N;i++)
    	{
    		for(int j=0;j<N;j++)
    		{
    			this.positions[i][j]=null;
     			
    		}
    	}
    	
    	creatures=null;
    }
    public void standinqueue(Creature[] creature,ZHENXING zhenxing)
    {
    	int usednumoflouluo=0;
    	int numofhuluwa=0;
    	if(creatures!=null)
    	{
    	Creature[] temp1=new Creature[creatures.length+creature.length];
    	for(int i=0;i<creatures.length;i++)
    	{
    		temp1[i]=creatures[i];
    	}
    	for(int i=creatures.length;i<creatures.length+creature.length;i++)
    	{
    		temp1[i]=creature[i-creatures.length];
    	}
    	creatures=temp1;
    	}
    	else
    		creatures=creature;
    	 for (int i = 0; i < creature.length; i++) {
    		 
    		 if(creature[i] instanceof  Xiezijing )
         	{
         		/*Random rand = new Random(); 
         		int j = rand.nextInt()%(N-1)+1;
         		int k = rand.nextInt()%(N-1)+1;*/
    			 creatures[i].setxy(0,N-1);
         		this.positions[0][N-1] =new Position(0,N-1);
         		creature[i].setPosition(this.positions[0][N-1]);
         	}
    		 else if(creature[i] instanceof  Huluwa)
    		 {
    			 creatures[i].setxy(numofhuluwa,0);
    			 this.positions[numofhuluwa][0] =new Position(numofhuluwa,0);
          		creature[i].setPosition(this.positions[numofhuluwa][0]);
          		numofhuluwa++;
    		 }
         	else if(creature[i] instanceof  Xiaolouluo )
         	{
         		if(zhenxing == ZHENXING.雁行 )
         		{
         			usednumoflouluo++;
         			this.positions[usednumoflouluo][N-1-usednumoflouluo] =new Position(usednumoflouluo,N-1-usednumoflouluo);
         			creature[i].setPosition(this.positions[usednumoflouluo][N-1-usednumoflouluo]);
         			creatures[i].setxy(usednumoflouluo,N-1-usednumoflouluo);
         		}
         		else if(zhenxing == ZHENXING.冲扼 )
         		{
         			usednumoflouluo++;
         			int a=usednumoflouluo%2;
         			this.positions[usednumoflouluo][N-1-a] =new Position(usednumoflouluo,N-1-a);
         			creature[i].setPosition(this.positions[usednumoflouluo][N-1-a]);
         			creatures[i].setxy(usednumoflouluo,N-1-a);
         		}
         		else if(zhenxing == ZHENXING.长蛇 )
         		{
         			usednumoflouluo++;
         	
         			this.positions[usednumoflouluo][N-1] =new Position(usednumoflouluo,N-1);
         			creature[i].setPosition(this.positions[usednumoflouluo][N-1]);
         			creatures[i].setxy(usednumoflouluo,N-1);
         		}
         		else
         		{
         			/*
         			 TODO: ��������
         			 */
         		}
         	}
         	else if(creature[i] instanceof  Yeye )
         	{
         		this.positions[7][0] =new Position(7,0);
 				creature[i].setPosition(this.positions[7][0]);
 				creatures[i].setxy(7,0);
         		
         	}
         	else if( creature[i] instanceof Shejing)
         	{
         		this.positions[7][N-1] =new Position(7,N-1);
 				creature[i].setPosition(this.positions[7][N-1]);
 				creatures[i].setxy(7,N-1);
         		
         	}
    	 }
    }
 
    public static void main(String[] args) {

        
      

    }
}
enum ZHENXING {
   长蛇,雁行,冲扼
}
