package default1;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import javax.swing.JFileChooser;
import javax.swing.filechooser.FileFilter;
public class FileTest {
 public static File showdata(String[] args) throws FileNotFoundException {
  // �����ļ�ѡ����
  JFileChooser fileChooser = new JFileChooser();
  // ���õ�ǰĿ¼
  fileChooser.setCurrentDirectory(new File("."));
  fileChooser.setAcceptAllFileFilterUsed(false);
  final String[][] fileENames = { { ".java", "JAVAԴ���� �ļ�(*.java)" },
          { ".doc", "MS-Word 2003 �ļ�(*.doc)" },
          { ".xls", "MS-Excel 2003 �ļ�(*.xls)" },
          {".txt","�浵�ļ�"}
           };
  
  // ��ʾ�����ļ�
  fileChooser.addChoosableFileFilter(new FileFilter() {
   public boolean accept(File file) {
    return true;
   }
   public String getDescription() {
    return "�����ļ�(*.*)";
   }
  });
  
  // ѭ�������Ҫ��ʾ���ļ�
  for (final String[] fileEName : fileENames) {
   
   fileChooser.setFileFilter(new javax.swing.filechooser.FileFilter() {
 
    public boolean accept(File file) { 
 
     if (file.getName().endsWith(fileEName[0]) || file.isDirectory()) {
 
      return true;
     }
 
     return false;
    }
 
    public String getDescription() {
 
     return fileEName[1];
    }
 
   });
  }
  
  fileChooser.showDialog(null, null);
  File file=fileChooser.getSelectedFile();
  return file;
 }
}