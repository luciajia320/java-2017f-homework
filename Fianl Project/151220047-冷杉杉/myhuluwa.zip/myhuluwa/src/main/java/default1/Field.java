package default1;

import java.awt.AWTException;
import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Robot;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.net.MalformedURLException;
import java.util.ArrayList;
import javax.swing.JPanel;

public class Field extends JPanel {

    private final int OFFSET = 0;
    private final int SPACE = 20;

    private ArrayList tiles = new ArrayList();
    //private ArrayList player = new ArrayList();
    Player player[]=new Player[16];
    int playerlength=0;
    private int w = 0;
    private int h = 0;
    private boolean completed = false;

    private String level =
            "..........\n" +
                    "..........\n" +
                    "..........\n" +
                    "..........\n" +
                    "..........\n" +
                    "..........\n" +
                    "..........\n" +
                    "..........\n";

    public Field() throws MalformedURLException {

        addKeyListener(new TAdapter());
        setFocusable(true);
        initWorld();
    }

    public int getBoardWidth() {
        return this.w;
    }

    public int getBoardHeight() {
        return this.h;
    }

    public final void initWorld() throws MalformedURLException {

        int x = OFFSET;
        int y = OFFSET;

        Tile a;


        for (int i = 0; i < level.length(); i++) {

            char item = level.charAt(i);

            if (item == '\n') {
                y += SPACE;
                if (this.w < x) {
                    this.w = x;
                }

                x = OFFSET;
            } else if (item == '.') {
                a = new Tile(x, y);
                tiles.add(a);
                x += SPACE;
            } else if (item == '@') {
                player[playerlength]=(new Player(x, y, this,SENIORITY.一));
                playerlength++;
                x += SPACE;
                Square.set(y,x,2);
            } else if (item == ' ') {
                x += SPACE;
            }

            h = y;
        }
        Square.reset();
        for (int i = 0; i < 7; i++) {
            player[i] = new Huluwa(COLOR.values()[i], SENIORITY.values()[i],0,i*SPACE,this);
            Square.set(i,0,1);
        }
        for(int i=7;i<=12;i++)
        {
        	 player[i]=new Xiaolouluo(SENIORITY.小喽啰,9*SPACE,(i-5)*SPACE,this);
        	 Square.set(i-5, 9, 2);
        }
        player[13]=new Yeye(SENIORITY.爷爷,0,7*SPACE,this);
        player[14]=new Xiezijing(SENIORITY.蝎子精,9*SPACE,0*SPACE,this);
        player[15]=new Shejing(SENIORITY.蛇精,9*SPACE,1*SPACE,this);
        Square.set(7,0,1);
        Square.set(0,9,2);
        Square.set(1,9,2);
        //Square.show();
        //player = new Player(0+ OFFSET,0+OFFSET, this);

    }
    public final void myinitWorld(File file,save a1) throws MalformedURLException {
    	
        	
        	
        
    	tiles.clear();
        int x = OFFSET;
        int y = OFFSET;

        Tile a;


        for (int i = 0; i < level.length(); i++) {

            char item = level.charAt(i);

            if (item == '\n') {
                y += SPACE;
                if (this.w < x) {
                    this.w = x;
                }

                x = OFFSET;
            } else if (item == '.') {
                a = new Tile(x, y);
                tiles.add(a);
                x += SPACE;
            } else if (item == '@') {
                player[playerlength]=(new Player(x, y, this,SENIORITY.小喽啰));
                playerlength++;
                x += SPACE;
                Square.set(y,x,2);
            } else if (item == ' ') {
                x += SPACE;
            }

            h = y;
        }
        
       
        Square.reset();
        synchronized(Square.square)
        {
        for(int i=0;i<8;i++)
		{
			for(int j=0;j<16;j++)
			{
					Square.set(i, j, a1.savedata[i][j]);
				
			}
		}
        
        
        for (int i = 0; i < 7; i++) {
        	int k=Square.find(i, 1);
            player[i] = new Huluwa(COLOR.values()[i], SENIORITY.values()[i],k*SPACE,i*SPACE,this);
            Square.set(i,k,1);
        }
        for(int i=7;i<=12;i++)
        {
        	int k=Square.find(i-5, 2);
        	if(k==-1)
        	{
        		player[i]=null;
        	}
        	else
        	{
        	 player[i]=new Xiaolouluo(SENIORITY.小喽啰,k*SPACE,(i-5)*SPACE,this);
        	 Square.set(i-5, k, 2);
        	}
        }
        int k1=Square.find(7, 1);
        player[13]=new Yeye(SENIORITY.爷爷,k1*SPACE,7*SPACE,this);
        Square.set(7,k1,1);
        k1=Square.find(0, 2);
        if(k1==-1)
    	{
    		player[14]=null;
    	}
        else
        {
        	player[14]=new Xiezijing(SENIORITY.蝎子精,k1*SPACE,0*SPACE,this);
        	Square.set(0,k1,2);
        }
        k1=Square.find(1, 2);
        if(k1==-1)
    	{
    		player[15]=null;
    	}
        else
        {
        	player[15]=new Shejing(SENIORITY.蛇精,k1*SPACE,1*SPACE,this);
        	Square.set(1,k1,2);
        }
        
        
        
        
        //Square.show();
        //player = new Player(0+ OFFSET,0+OFFSET, this);
        }
        if (completed) {
            completed = false;
        }
        

    }

    public void buildWorld(Graphics g) {

        g.setColor(new Color(250, 240, 170));
        g.fillRect(0, 0, this.getWidth(), this.getHeight());

        ArrayList world = new ArrayList();
        world.addAll(tiles);

        for(int i=0;i<16;i++)

        world.add(player[i]);


        for (int i = 0; i < world.size(); i++) {

            Thing2D item = (Thing2D) world.get(i);

            if (item instanceof Player) {
               g.drawImage(item.getImage(), item.x() + 2, item.y() + 2, this);
            	
            } else {
            	if(item!=null)
                g.drawImage(item.getImage(), item.x(), item.y(), this);
            }

            if (completed) {
                g.setColor(new Color(0, 0, 0));
                g.drawString("Completed", 25, 20);
            }

        }
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        buildWorld(g);
    }

    class TAdapter extends KeyAdapter {
    	Thread[] mythread=new Thread[16];
    	@Override
        public void keyReleased(KeyEvent e) {
    		int key = e.getKeyCode();
            

            if (key == KeyEvent.VK_SPACE) {
            	for(int i=0;i<16;i++)
            	{
            		if(player[i]!=null)
            		mythread[i].interrupt();
            	}
            }
    	}
        @Override
        public void keyPressed(KeyEvent e) {

            if (completed) {
                return;
            }


            int key = e.getKeyCode();
            

            if (key == KeyEvent.VK_LEFT) {

            	Square.set(player[0].y()/SPACE, player[0].x()/SPACE, 0);
            	Square.set(player[0].y()/SPACE, player[0].x()/SPACE-1, 1);
                
                Square.show();

            } else if (key == KeyEvent.VK_RIGHT) {

            	Square.set(player[0].y()/SPACE, player[0].x()/SPACE, 0);
            	Square.set(player[0].y()/SPACE, player[0].x()/SPACE+1, 1);
                
                player[0].move(SPACE, 0);
                

            } else if (key == KeyEvent.VK_UP) {

            	Square.set(player[0].y()/SPACE, player[0].x()/SPACE, 0);
            	Square.set(player[0].y()/SPACE-1, player[0].x()/SPACE, 1);
                
                player[0].move(0, -SPACE);

            } else if (key == KeyEvent.VK_DOWN) {
            	Square.set(player[0].y()/SPACE, player[0].x()/SPACE, 0);
            	Square.set(player[0].y()/SPACE+1, player[0].x()/SPACE, 1);
            	
                

                player[0].move(0, SPACE);

            } 
            else if (key == KeyEvent.VK_S) {
            	save a=new save();
            	a.mysave();
            	
                

            } 
            else if (key == KeyEvent.VK_SPACE) {
            	for(int i=0;i<16;i++)
            	{
            		if(player[i]!=null)
            		{
            		mythread[i]=new Thread(player[i]);
            		mythread[i].start();
            		}
            	}
                

            } 
            else if (key == KeyEvent.VK_L) {
            	File file=null;
            	try {
					file=FileTest.showdata(null);
				} catch (FileNotFoundException e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				}
				Square.reset();
				playerlength=0;
				save temp1=new save();
				save[] a1=temp1.myload(file);
			
				for(int i1=0;i1<a1.length;i1++)
				{
					
				try {
					
					myinitWorld(file,a1[i1]);
					
				} catch (MalformedURLException e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				}
				}
				
				
            } else if (key == KeyEvent.VK_R) {
                try {
                	Square.reset();
                	playerlength=0;
					restartLevel();
				} catch (MalformedURLException e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				}
            }

            repaint();
        }
    }


    public void restartLevel() throws MalformedURLException {

        tiles.clear();
        initWorld();
        if (completed) {
            completed = false;
        }
    }
    
}
