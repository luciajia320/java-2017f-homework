package default1;
import java.io.*;

public class Savetest {
	public static void main(String args[]) throws FileNotFoundException{  
	      ObjectOutputStream oos=null;  
	      try{  
	         oos=new ObjectOutputStream(new FileOutputStream("test.txt"));  
	         save a=new save();
	         for(int i=0;i<8;i++)
	 		 {
	 			for(int j=0;j<16;j++)
	 			{
	 					a.savedata[i][j]=i;
	 				
	 			}
	 		 }
	  
	         oos.writeObject(a);
	         save b=new save();
	         for(int i=0;i<8;i++)
		 	{
		 			for(int j=0;j<16;j++)
		 			{
		 					b.savedata[i][j]=9-i;
		 				
		 			}
		 	}
	         oos.writeObject(b);  
	        }catch(Exception e){  
	             e.printStackTrace();  
	        }finally{  
	             if(oos!=null)  
	             try{  
	                oos.close();  
	              }catch(Exception e){  
	                   e.printStackTrace();  
	             }  
	          }  
	      ObjectInputStream ois=null; 
	      try {
			ois=new ObjectInputStream(  
			     new FileInputStream("test.txt"));
			while (true) {
                save p = (save)ois.readObject();
                System.out.println(p);
            }
		} catch (EOFException e) {//ͨ���쳣���ж��ļ���ȡ����β
            System.out.println("�ļ���ȡ��ϣ�");}
	      catch (Exception e) {//
	          e.printStackTrace();
	      
	      
}}}
