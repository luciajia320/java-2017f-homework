package default1;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Vector;

public class writefile {
	public static Vector<save> all=new Vector<save>();
	writefile()
	{
		all=new Vector<save>();
	}
	public static void writein() throws FileNotFoundException, IOException
	{
		
		ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream("test.txt")); 
		for(int i=0;i<all.size();i++)
		{
			oos.writeObject(all.get(i));
		}
		oos.close();
		
		ObjectInputStream ois=null; 
		try {
			ois=new ObjectInputStream(  
			     new FileInputStream("test.txt"));
			while (true) {
                System.out.println((save)ois.readObject());
                
            }
		} catch (EOFException e) {//ͨ���쳣���ж��ļ���ȡ����β
            //System.out.println("�ļ���ȡ��ϣ�");
			}
	      catch (Exception e) {//
	          e.printStackTrace();
      }
	}
}
