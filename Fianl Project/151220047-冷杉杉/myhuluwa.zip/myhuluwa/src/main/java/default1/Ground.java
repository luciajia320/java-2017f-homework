package default1;


import java.io.FileNotFoundException;
import java.net.MalformedURLException;

import javax.swing.JFrame;


public final class Ground extends JFrame {

    private final int OFFSET = 0;


    public Ground() throws MalformedURLException {
        InitUI();
    }

    public void InitUI() throws MalformedURLException {
        Field field = new Field();
        add(field);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //setSize(field.getBoardWidth() + OFFSET,
       //         field.getBoardHeight() + 2 * OFFSET);
        setSize(field.getBoardWidth() + 30,
                field.getBoardHeight() + 60);
        setLocationRelativeTo(null);
        setTitle("Ground");
    }


    public static void main(String[] args) throws MalformedURLException, FileNotFoundException {
        Ground ground = new Ground();
        ground.setVisible(true);
    }
}