package default1;
public class Square {
	public static int[][] square=new int [8][16];
	Square()
	{
		for(int i=0;i<8;i++)
		{
			for(int j=1;j<16;j++)
			{
					square[i][j]=0;
				
			}
		}
	}
	public static int find(int i,int k)
	{
		for(int j=0;j<16;j++)
		{
			if(square[i][j]==k)
			{
				return j;
			}
		}
		return -1;
	}
	public static void reset()
	{
		for(int i=0;i<8;i++)
		{
			for(int j=0;j<16;j++)
			{
					square[i][j]=0;
				
			}
		}
	}
	public static void set(int x,int y,int key)
	{
		square[x][y]=key;
	}
	public static int get(int x,int y)
	{
		return square[x][y];
	}
	public static void show()
	{
		System.out.println();
		for(int i=0;i<8;i++)
		{
			for(int j=0;j<16;j++)
			{
					System.out.print (square[i][j]+"	");
					
			}
			System.out.println();
		}
		System.out.println();
	}
	public static boolean check()
	{
		for(int i=0;i<8;i++)
		{
			for(int j=0;j<16;j++)
			{
					if(square[i][j]==2)
						return true;
			}
			
		}
		return false;
	}
}
